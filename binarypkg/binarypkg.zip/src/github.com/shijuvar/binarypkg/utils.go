//go:binary-only-package

package utils
